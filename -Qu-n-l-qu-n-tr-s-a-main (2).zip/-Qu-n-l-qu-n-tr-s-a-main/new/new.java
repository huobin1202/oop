public void tim(){
    Scanner sc= new Scanner(System.in);
    System.out.print("Nhap ten khach hang can tim");
    String tenKH= sc.nextLine();
    timtt(tenKH);
}
public void timtt(String tenKH){
    boolean x= false;
    for(int i=0;i<n;i++){
        if(dskhachhang[i].getTenKH().equals(tenKH)){
            dskhachhang[i].xuat();
            x=true;
        }
    }
    if(x==false){
        System.out.print("Khong tim thay khach hang!");
    }
}